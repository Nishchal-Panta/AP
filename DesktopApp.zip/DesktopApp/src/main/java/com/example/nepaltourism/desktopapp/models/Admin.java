package com.example.nepaltourism.desktopapp.models;
public class Admin extends User {
    public Admin(String id, String name, String password) {
        super(id, name, password, "");
    }
}
