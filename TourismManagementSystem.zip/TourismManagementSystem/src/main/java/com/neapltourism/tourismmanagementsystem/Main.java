package com.neapltourism.tourismmanagementsystem;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    private static Stage primaryStage;

    public static void changeScene(String fxmlPath, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource(fxmlPath));
            Parent root = loader.load();
            primaryStage.setScene(new Scene(root));
            primaryStage.setTitle(title);
            primaryStage.show();
        } catch (Exception e) {
            System.out.println("❌ Failed to load scene: " + fxmlPath);
            e.printStackTrace();
        }
    }

    @Override
    public void start(Stage stage) {
        primaryStage = stage;
        changeScene("/com/neapltourism/view/login.fxml", "Tourism Management - Login");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
