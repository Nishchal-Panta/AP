package com.neapltourism.tourismmanagementsystem.controller;

import com.neapltourism.tourismmanagementsystem.model.User;
import com.neapltourism.tourismmanagementsystem.utils.LoginManager;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Button loginButton;
    @FXML private Label errorLabel;

    @FXML
    public void initialize() {
        errorLabel.setText("");
    }

    @FXML
    public void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        User user = LoginManager.authenticate(username, password);
        if (user != null) {
            try {
                // ✅ Fix the FXML path here
                FXMLLoader loader = new FXMLLoader(LoginController.class.getResource("/com/neapltourism/view/Bookings.fxml"));
                System.out.println(LoginController.class.getResource("/com/neapltourism/view/Bookings.fxml"));
                Parent root = loader.load();

                BookingController bookingController = loader.getController();
                bookingController.setUser(user);

                Stage stage = (Stage) loginButton.getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.setTitle("Tourism Booking");
                stage.show();

            } catch (Exception e) {
                e.printStackTrace();
                errorLabel.setText("Error loading booking screen.");
            }
        } else {
            errorLabel.setText("Invalid credentials. Try again.");
        }
    }
}
