package com.neapltourism.tourismmanagementsystem.utils;
import com.neapltourism.tourismmanagementsystem.model.Booking;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookingStats {

    // 📈 Total bookings
    public static int totalBookings(List<Booking> bookings) {
        return bookings.size();
    }

    // 🚨 Emergency bookings
    public static int countEmergency(List<Booking> bookings) {
        return (int) bookings.stream()
                .filter(b -> b.getStatus().toLowerCase().contains("emergency"))
                .count();
    }

    // 🌸 Festival discounts applied
    public static int countFestivalDiscounts(List<Booking> bookings) {
        return (int) bookings.stream()
                .filter(b -> b.getStatus().toLowerCase().contains("dashain") ||
                        b.getStatus().toLowerCase().contains("tihar"))
                .count();
    }

    // 🗺️ Count per attraction
    public static Map<String, Integer> bookingsByAttraction(List<Booking> bookings) {
        Map<String, Integer> attractionMap = new HashMap<>();
        for (Booking b : bookings) {
            String attraction = b.getAttraction();
            attractionMap.put(attraction, attractionMap.getOrDefault(attraction, 0) + 1);
        }
        return attractionMap;
    }

    // 📆 Monthly booking count
    public static Map<String, Integer> bookingsByMonth(List<Booking> bookings) {
        Map<String, Integer> monthMap = new HashMap<>();
        for (Booking b : bookings) {
            LocalDate date = b.getDate();
            String monthLabel = date.getMonth().name(); // e.g. "JANUARY"
            monthMap.put(monthLabel, monthMap.getOrDefault(monthLabel, 0) + 1);
        }
        return monthMap;
    }
}