package com.neapltourism.tourismmanagementsystem.controller;
import com.neapltourism.tourismmanagementsystem.model.Attraction;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class AttractionController {

    @FXML private TableView<Attraction> attractionTable;
    @FXML private TableColumn<Attraction, String> nameColumn, typeColumn, locationColumn, difficultyColumn;
    @FXML private TableColumn<Attraction, Integer> altitudeColumn;

    private final ObservableList<Attraction> attractionList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        nameColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getName()));
        typeColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getType()));
        locationColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getLocation()));
        difficultyColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getDifficulty()));
        altitudeColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getAltitude()).asObject());

        attractionTable.setItems(attractionList);
    }

    @FXML
    public void handleAdd() {
        Attraction a = new Attraction("Annapurna Circuit", "Trek", "Pokhara", "Hard", 4200);
        attractionList.add(a);
    }

    @FXML
    public void handleEdit() {
        Attraction selected = attractionTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            selected.setDifficulty("Moderate");
            attractionTable.refresh();
        } else {
            showAlert("Select an attraction to edit.");
        }
    }

    @FXML
    public void handleDelete() {
        Attraction selected = attractionTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            attractionList.remove(selected);
        } else {
            showAlert("Select an attraction to delete.");
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}