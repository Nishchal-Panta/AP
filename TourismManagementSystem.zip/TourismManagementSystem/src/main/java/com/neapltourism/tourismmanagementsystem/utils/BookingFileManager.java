package com.neapltourism.tourismmanagementsystem.utils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.neapltourism.tourismmanagementsystem.model.Booking;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.*;
import java.lang.reflect.Type;
import java.util.List;

public class BookingFileManager {
    private static final String FILE_PATH = "bookings.json";

    public static ObservableList<Booking> loadBookings() {
        try (Reader reader = new FileReader(FILE_PATH)) {
            Type listType = new TypeToken<List<Booking>>() {}.getType();
            List<Booking> bookings = new Gson().fromJson(reader, listType);
            return FXCollections.observableArrayList(bookings);
        } catch (IOException e) {
            return FXCollections.observableArrayList();
        }
    }

    public static void saveBookings(ObservableList<Booking> bookings) {
        try (Writer writer = new FileWriter(FILE_PATH)) {
            new Gson().toJson(bookings, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}