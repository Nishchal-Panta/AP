package com.neapltourism.tourismmanagementsystem.utils;
import com.neapltourism.tourismmanagementsystem.model.Tourist;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TouristDataReader {

    public static List<Tourist> loadFromFile(String filename) {
        List<Tourist> tourists = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    tourists.add(new Tourist(parts[0], parts[1], Integer.parseInt(parts[2])));
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading tourist data: " + e.getMessage());
        }
        return tourists;
    }
}