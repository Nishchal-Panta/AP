package com.neapltourism.tourismmanagementsystem.controller;
import com.neapltourism.tourismmanagementsystem.model.Tourist;
import com.neapltourism.tourismmanagementsystem.utils.LanguageManager;
import com.neapltourism.tourismmanagementsystem.utils.TouristDataReader;
import com.neapltourism.tourismmanagementsystem.utils.TouristDataWriter;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.List;

public class TouristController {

    @FXML private TableView<Tourist> touristTable;
    @FXML private TableColumn<Tourist, String> nameColumn, nationalityColumn;
    @FXML private TableColumn<Tourist, Integer> ageColumn;

    @FXML private TextField nameField, nationalityField;
    @FXML private Spinner<Integer> ageSpinner;

    @FXML private Button addButton, saveButton, loadButton;
    @FXML private Label titleLabel;
    @FXML private ComboBox<String> languageComboBox;

    private final ObservableList<Tourist> touristList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Table setup
        nameColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getName()));
        nationalityColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getNationality()));
        ageColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getAge()).asObject());

        touristTable.setItems(touristList);

        ageSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(5, 100, 30));

        // Language setup
        languageComboBox.getItems().addAll("en", "ne", "hi");
        languageComboBox.setValue("en"); // Default
        languageComboBox.setOnAction(e -> {
            LanguageManager.setLanguage(languageComboBox.getValue());
            updateUIText();
        });

        updateUIText();
    }

    @FXML
    public void handleAddTourist() {
        String name = nameField.getText().trim();
        String nationality = nationalityField.getText().trim();
        int age = ageSpinner.getValue();

        if (!name.isEmpty() && !nationality.isEmpty()) {
            touristList.add(new Tourist(name, nationality, age));
            nameField.clear();
            nationalityField.clear();
            ageSpinner.getValueFactory().setValue(30);
        } else {
            showAlert(LanguageManager.get("error.fillFields"));
        }
    }

    @FXML
    public void handleSaveTourists() {
        TouristDataWriter.saveToFile(touristList, "data/tourists.csv");
        showAlert(LanguageManager.get("message.saveSuccess"));
    }

    @FXML
    public void handleLoadTourists() {
        List<Tourist> loaded = TouristDataReader.loadFromFile("data/tourists.csv");
        touristList.setAll(loaded);
        showAlert(LanguageManager.get("message.loadSuccess"));
    }

    private void updateUIText() {
        titleLabel.setText(LanguageManager.get("label.touristTitle"));
        addButton.setText(LanguageManager.get("button.add"));
        saveButton.setText(LanguageManager.get("button.save"));
        loadButton.setText(LanguageManager.get("button.load"));
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}