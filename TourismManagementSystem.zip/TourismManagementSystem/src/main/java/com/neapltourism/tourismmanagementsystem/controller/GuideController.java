package com.neapltourism.tourismmanagementsystem.controller;
import com.neapltourism.tourismmanagementsystem.model.Guide;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class GuideController {

    @FXML private TableView<Guide> guideTable;
    @FXML private TableColumn<Guide, String> nameColumn;
    @FXML private TableColumn<Guide, String> languagesColumn;
    @FXML private TableColumn<Guide, Integer> experienceColumn;

    private final ObservableList<Guide> guideList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        nameColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getName()));
        languagesColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getLanguages()));
        experienceColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getExperience()).asObject());
        guideTable.setItems(guideList);
    }

    @FXML
    public void handleAdd() {
        Guide newGuide = new Guide("New Guide", "English/Nepali", 5);
        guideList.add(newGuide);
    }

    @FXML
    public void handleEdit() {
        Guide selected = guideTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            selected.setLanguages("Updated Lang");
            selected.setExperience(selected.getExperience() + 1);
            guideTable.refresh();
        } else {
            showAlert("Please select a guide to edit.");
        }
    }

    @FXML
    public void handleDelete() {
        Guide selected = guideTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            guideList.remove(selected);
        } else {
            showAlert("Please select a guide to delete.");
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Notice");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
