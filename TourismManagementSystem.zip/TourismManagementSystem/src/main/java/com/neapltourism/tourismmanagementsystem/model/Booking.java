package com.neapltourism.tourismmanagementsystem.model;
import java.time.LocalDate;

public class Booking {
    private String tourist;
    private String guide;
    private String attraction;
    private LocalDate date;
    private String status;

    public Booking(String tourist, String guide, String attraction, LocalDate date, String status) {
        this.tourist = tourist;
        this.guide = guide;
        this.attraction = attraction;
        this.date = date;
        this.status = status;
    }

    public String getTourist() { return tourist; }
    public String getGuide() { return guide; }
    public String getAttraction() { return attraction; }
    public LocalDate getDate() { return date; }
    public String getStatus() { return status; }

    public void setStatus(String status) { this.status = status; }
}