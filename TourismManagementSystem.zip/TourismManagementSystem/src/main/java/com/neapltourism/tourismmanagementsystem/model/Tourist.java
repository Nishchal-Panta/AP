package com.neapltourism.tourismmanagementsystem.model;

public class Tourist {
    private String name;
    private String nationality;
    private int age;

    // Constructor
    public Tourist(String name, String nationality, int age) {
        this.name = name;
        this.nationality = nationality;
        this.age = age;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getNationality() {
        return nationality;
    }

    public int getAge() {
        return age;
    }

    // Optional Setters (in case you need to edit values later)
    public void setName(String name) {
        this.name = name;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public void setAge(int age) {
        this.age = age;
    }

    // Optional: toString() for debugging
    @Override
    public String toString() {
        return name + " (" + nationality + "), Age: " + age;
    }
}