package com.neapltourism.tourismmanagementsystem.utils;

import java.util.Locale;
import java.util.ResourceBundle;

public class LanguageManager {
    private static ResourceBundle bundle = ResourceBundle.getBundle("lang.messages", Locale.ENGLISH);

    public static void setLanguage(String languageCode) {
        Locale locale = new Locale(languageCode);
        bundle = ResourceBundle.getBundle("lang/messages", locale);
    }

    public static String get(String key) {
        return bundle.getString(key);
    }
}