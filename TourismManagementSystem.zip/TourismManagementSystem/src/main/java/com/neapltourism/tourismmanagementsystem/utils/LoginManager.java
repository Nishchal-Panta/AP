package com.neapltourism.tourismmanagementsystem.utils;
import com.neapltourism.tourismmanagementsystem.model.User;

public class LoginManager {
    public static User authenticate(String username, String password) {
        if (username.equals("admin") && password.equals("admin123")) {
            return new User("admin", "admin123", "admin");
        } else if (username.equals("guide") && password.equals("guide123")) {
            return new User("guide", "guide123", "guide");
        } else if (username.equals("tourist") && password.equals("tour123")) {
            return new User("tourist", "tour123", "tourist");
        }
        return null;
    }
}