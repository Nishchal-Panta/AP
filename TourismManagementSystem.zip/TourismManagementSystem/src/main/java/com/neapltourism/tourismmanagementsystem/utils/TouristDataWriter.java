package com.neapltourism.tourismmanagementsystem.utils;
import com.neapltourism.tourismmanagementsystem.model.Tourist;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class TouristDataWriter {

    public static void saveToFile(List<Tourist> tourists, String filename) {
        try (FileWriter writer = new FileWriter(filename)) {
            for (Tourist t : tourists) {
                writer.write(t.getName() + "," + t.getNationality() + "," + t.getAge() + "\n");
            }
        } catch (IOException e) {
            System.err.println("Error saving tourist data: " + e.getMessage());
        }
    }
}