package com.neapltourism.tourismmanagementsystem.controller;
import javafx.fxml.FXML;
import javafx.scene.chart.*;

public class AnalyticsController {

    @FXML private PieChart destinationChart;
    @FXML private BarChart<String, Number> monthlyChart;

    @FXML
    public void initialize() {
        // PieChart – Popular Destinations
        destinationChart.getData().addAll(
                new PieChart.Data("Pokhara", 45),
                new PieChart.Data("Everest", 30),
                new PieChart.Data("Chitwan", 15),
                new PieChart.Data("Lumbini", 10)
        );

        // BarChart – Monthly Bookings
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("2025");

        series.getData().add(new XYChart.Data<>("Jan", 10));
        series.getData().add(new XYChart.Data<>("Feb", 15));
        series.getData().add(new XYChart.Data<>("Mar", 25));
        series.getData().add(new XYChart.Data<>("Apr", 30));
        series.getData().add(new XYChart.Data<>("May", 20));
        series.getData().add(new XYChart.Data<>("Jun", 8)); // Monsoon dip
        series.getData().add(new XYChart.Data<>("Oct", 40)); // Dashain surge

        monthlyChart.getData().add(series);
    }
}