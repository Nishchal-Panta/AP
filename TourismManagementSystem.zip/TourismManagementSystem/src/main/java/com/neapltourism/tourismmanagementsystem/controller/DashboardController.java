package com.neapltourism.tourismmanagementsystem.controller;
import com.neapltourism.tourismmanagementsystem.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.text.Text;

public class DashboardController {

    @FXML
    private Button guideBtn;

    @FXML
    private Button attractionBtn;

    @FXML
    private Button bookingBtn;

    @FXML
    private Button analyticsBtn;

    @FXML
    private Button logoutBtn;

    @FXML
    private Text welcomeText;

    @FXML
    public void initialize() {
        // You can personalize this later with logged-in user info
        welcomeText.setText("Welcome to Tourism Dashboard 🌄");
    }

    @FXML
    private void goToGuides(ActionEvent event) {
        Main.changeScene("/views/Guide.fxml", "Guides");
    }

    @FXML
    private void goToAttractions(ActionEvent event) {
        Main.changeScene("/views/Attraction.fxml", "Attractions");
    }

    @FXML
    private void goToBookings(ActionEvent event) {
        Main.changeScene("/views/Booking.fxml", "Bookings");
    }

    @FXML
    private void goToAnalytics(ActionEvent event) {
        Main.changeScene("/views/Analytics.fxml", "Analytics");
    }

    @FXML
    private void logout(ActionEvent event) {
        Main.changeScene("/views/Login.fxml", "Login");
    }
}
