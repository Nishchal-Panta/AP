package com.neapltourism.tourismmanagementsystem.controller;
import com.neapltourism.tourismmanagementsystem.model.Booking;
import com.neapltourism.tourismmanagementsystem.model.User;
import com.neapltourism.tourismmanagementsystem.utils.BookingFileManager;
import com.neapltourism.tourismmanagementsystem.utils.LanguageManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.time.LocalDate;

public class BookingController {

    @FXML private TableView<Booking> bookingTable;
    @FXML private TableColumn<Booking, String> touristColumn, guideColumn, attractionColumn, statusColumn;
    @FXML private TableColumn<Booking, LocalDate> dateColumn;

    @FXML private Label titleLabel;
    @FXML private Button bookButton, cancelButton, emergencyButton;
    @FXML private ComboBox<String> languageComboBox;
    @FXML private TextField filterField;

    private final ObservableList<Booking> bookingList = FXCollections.observableArrayList();

    private User loggedInUser;

    @FXML
    public void initialize() {
        // Table setup
        touristColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getTourist()));
        guideColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getGuide()));
        attractionColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getAttraction()));
        dateColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleObjectProperty<>(data.getValue().getDate()));
        statusColumn.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getStatus()));

        bookingList.addAll(BookingFileManager.loadBookings());
        bookingTable.setItems(bookingList);

        // Language switching
        languageComboBox.getItems().addAll("en", "ne", "hi");
        languageComboBox.setValue("en");
        languageComboBox.setOnAction(e -> {
            LanguageManager.setLanguage(languageComboBox.getValue());
            updateUIText();
        });

        // Filter logic
        filterField.textProperty().addListener((obs, oldVal, newVal) -> applyFilter(newVal));

        updateUIText();
    }

    @FXML
    public void handleAddBooking() {
        LocalDate today = LocalDate.now();
        String status = LanguageManager.get("status.confirmed");

        int month = today.getMonthValue();
        int day = today.getDayOfMonth();

        if (month == 10 && day >= 12 && day <= 25) {
            status += " - " + LanguageManager.get("festival.dashain");
        } else if (month == 11 && day >= 1 && day <= 5) {
            status += " - " + LanguageManager.get("festival.tihar");
        }

        if (month >= 6 && month <= 8) {
            showAlert(LanguageManager.get("warning.monsoon"));
        }

        Booking newBooking = new Booking("Ram", "Pema", "Everest Base Camp", today, status);
        bookingList.add(newBooking);
        BookingFileManager.saveBookings(bookingList);
    }

    @FXML
    public void handleCancelBooking() {
        Booking selected = bookingTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            selected.setStatus(LanguageManager.get("status.cancelled"));
            bookingTable.refresh();
            BookingFileManager.saveBookings(bookingList);
        } else {
            showAlert(LanguageManager.get("error.selectCancel"));
        }
    }

    @FXML
    public void handleEmergency() {
        Booking selected = bookingTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            selected.setStatus(LanguageManager.get("status.emergency") + " (" + LocalDate.now() + ")");
            bookingTable.refresh();
            showAlert(LanguageManager.get("message.emergencyReported"));
            BookingFileManager.saveBookings(bookingList);
        } else {
            showAlert(LanguageManager.get("error.selectEmergency"));
        }
    }

    private void applyFilter(String keyword) {
        ObservableList<Booking> filtered = bookingList.filtered(b ->
                b.getTourist().toLowerCase().contains(keyword.toLowerCase()) ||
                        b.getGuide().toLowerCase().contains(keyword.toLowerCase()) ||
                        b.getAttraction().toLowerCase().contains(keyword.toLowerCase())
        );
        bookingTable.setItems(filtered);
    }

    private void updateUIText() {
        titleLabel.setText(LanguageManager.get("label.bookingTitle"));
        bookButton.setText(LanguageManager.get("button.book"));
        cancelButton.setText(LanguageManager.get("button.cancel"));
        emergencyButton.setText(LanguageManager.get("button.emergency"));
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void setUser(User user) {
        this.loggedInUser = user;

        if (user.getRole().equalsIgnoreCase("tourist")) {
            bookButton.setDisable(true);
            emergencyButton.setDisable(true);
            cancelButton.setDisable(true);
        }
    }
    @FXML
    public void handleAdd(ActionEvent event) {
        // TODO: Add booking logic
        System.out.println("Add Booking clicked");
    }

    @FXML
    public void handleCancel(ActionEvent event) {
        // TODO: Cancel booking logic
        System.out.println("Cancel Booking clicked");
    }

    @FXML
    public void handleEmergency(ActionEvent event) {
        // TODO: Emergency logic
        System.out.println("Emergency clicked");
    }
}

