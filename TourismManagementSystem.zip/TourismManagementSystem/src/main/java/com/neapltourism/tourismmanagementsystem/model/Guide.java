package com.neapltourism.tourismmanagementsystem.model;
public class Guide {
    private String name;
    private String languages;
    private int experience; // in years

    public Guide(String name, String languages, int experience) {
        this.name = name;
        this.languages = languages;
        this.experience = experience;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getLanguages() { return languages; }
    public void setLanguages(String languages) { this.languages = languages; }

    public int getExperience() { return experience; }
    public void setExperience(int experience) { this.experience = experience; }
}