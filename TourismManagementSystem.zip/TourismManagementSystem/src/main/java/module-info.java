module com.neapltourism.tourismmanagementsystem {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;


    opens com.neapltourism.tourismmanagementsystem to javafx.fxml;
    exports com.neapltourism.tourismmanagementsystem;
    exports com.neapltourism.tourismmanagementsystem.controller;
    opens com.neapltourism.tourismmanagementsystem.controller to javafx.fxml;
}